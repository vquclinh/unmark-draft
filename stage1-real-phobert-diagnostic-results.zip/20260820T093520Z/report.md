# UNMARK Stage-1 Real PhoBERT Diagnostic

- Run id: `20260820T093520Z`
- Repository HEAD: `6eb053f2b90b7c82fbfd50c5b33287551448691b`
- Status: **STAGE1_REAL_PHOBERT_DIAGNOSTIC_COMPLETE**
- Checkpoint: `vinai/phobert-base`
- Revision: `01daacda68afe13d83023d16ec647239e344a1e6`

## Scope

Diagnostic integration only.

- Real PhoBERT weights loaded: YES
- Three Stage-1 branches executed: YES
- Diagnostic backward calls: 1
- Optimizer created: NO
- Parameter update: NO
- Scientific training: NO
- Diagnostic lambdas: 1.0 / 1.0
- Diagnostic values resolve scientific OPEN decisions: NO

## Loss

- total: `1.079911708831787`
- align: `0.5320950746536255`
- clean: `0.5478166341781616`

## Shape

- pooled: `[2, 768]`
- reference padded width: `19`
- base padded width: `20`

## Parameter partition

- adapter trainable: `3551232`
- expected: `3551232`
- encoder trainable: `0`

## Verdict checks

| # | Check | Result |
|---:|---|---|
| 1 | exact tokenizer revision verified | PASS |
| 2 | exact model revision verified | PASS |
| 3 | run purpose is diagnostic | PASS |
| 4 | real model weights loaded | PASS |
| 5 | real reference/base padded widths differ | PASS |
| 6 | tone corruption changed at least one channel value | PASS |
| 7 | tone-only corruption preserves letter channel | PASS |
| 8 | loss total finite | PASS |
| 9 | loss align finite | PASS |
| 10 | loss clean finite | PASS |
| 11 | loss carries adapted graph | PASS |
| 12 | distance vectors have batch shape | PASS |
| 13 | pooled reference shape is [B,d] | PASS |
| 14 | pooled adapted-clean shape is [B,d] | PASS |
| 15 | pooled adapted-corrupt shape is [B,d] | PASS |
| 16 | corrupted channels affect adapted representation | PASS |
| 17 | adapter parameter count exact | PASS |
| 18 | encoder trainable parameter count is zero | PASS |
| 19 | encoder remains eval | PASS |
| 20 | adapter remains training mode | PASS |
| 21 | verified PhoBERT position profile | PASS |
| 22 | exactly one backward | PASS |
| 23 | all adapter gradient tensors present | PASS |
| 24 | all adapter gradients finite | PASS |
| 25 | at least one adapter gradient nonzero | PASS |
| 26 | encoder has zero gradient tensors | PASS |
| 27 | adapter parameter data unchanged | PASS |
| 28 | encoder parameter data unchanged | PASS |
| 29 | no optimizer created | PASS |
| 30 | no parameter update performed | PASS |
| 31 | no scientific training performed | PASS |

**31/31 checks PASS.**

This artifact is not a training result.
